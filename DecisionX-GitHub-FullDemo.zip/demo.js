
function analyzeData(){
    let file = document.getElementById('datafile').files[0];
    if(!file){
        alert("Please select a file first!");
        return;
    }
    let resultDiv = document.getElementById('result');
    resultDiv.innerHTML = `
        <h3>AI Insights:</h3>
        <p>Revenue trend indicates a potential <strong>15% growth</strong>.</p>
        <p>Customer churn risk detected: <strong>Moderate</strong>.</p>
        <p>Operational efficiency opportunities: <strong>3 areas</strong>.</p>
    `;
}
